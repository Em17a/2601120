import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { findOrCreateMatch, joinMatchmaking, pollMatchmaking, cancelMatchmaking } from '../src/matchmaking-service.ts';
import { isMatchCompatible, chooseMatchPartner, assignMatchRoles } from '../src/matchmaking-core.ts';
import { handleMatchmakingApi } from '../src/matchmaking-api.ts';

function createD1() {
  const sqlite = new DatabaseSync(':memory:');
  sqlite.exec(`
    CREATE TABLE rooms (
      code TEXT PRIMARY KEY, created_at INTEGER NOT NULL,
      last_active_at INTEGER NOT NULL, expires_at INTEGER NOT NULL
    );
    CREATE TABLE messages (id INTEGER PRIMARY KEY AUTOINCREMENT, room_code TEXT NOT NULL, body TEXT NOT NULL DEFAULT '');
    CREATE TABLE room_members (
      id TEXT PRIMARY KEY, room_code TEXT NOT NULL, nickname TEXT NOT NULL,
      role TEXT NOT NULL, joined_at INTEGER NOT NULL, last_seen_at INTEGER NOT NULL,
      left_at INTEGER
    );
    CREATE TABLE matchmaking_queue (
      client_id TEXT PRIMARY KEY, nickname TEXT NOT NULL, gender TEXT NOT NULL,
      preference TEXT NOT NULL, role_preference TEXT NOT NULL DEFAULT 'any',
      voice_preference TEXT NOT NULL DEFAULT 'any', matched_role TEXT,
      status TEXT NOT NULL DEFAULT 'waiting', room_code TEXT,
      created_at INTEGER NOT NULL, last_seen_at INTEGER NOT NULL
    );
  `);
  const prepare = sql => {
    const statement = sqlite.prepare(sql);
    return {
      bind(...values) {
        return {
          first: async () => statement.get(...values),
          all: async () => ({ results: statement.all(...values) }),
          run: async () => ({ meta: { changes: statement.run(...values).changes } }),
          _run: () => statement.run(...values),
        };
      },
    };
  };
  return {
    prepare,
    async batch(statements) {
      sqlite.exec('BEGIN');
      try {
        const results = statements.map(statement => statement._run());
        sqlite.exec('COMMIT');
        return results.map(result => ({ meta: { changes: result.changes } }));
      } catch (error) {
        sqlite.exec('ROLLBACK');
        throw error;
      }
    },
    raw: sqlite,
    close: () => sqlite.close(),
  };
}

function queue(db, id, overrides = {}) {
  db.raw.prepare(`INSERT INTO matchmaking_queue
    (client_id,nickname,gender,preference,role_preference,voice_preference,status,created_at,last_seen_at)
    VALUES(?,?,?,?,?,?,'waiting',?,?)`).run(
    id, overrides.nickname ?? id.slice(0, 6),
    overrides.gender ?? 'male', overrides.preference ?? 'any',
    overrides.role ?? 'any', overrides.voice ?? 'any',
    overrides.createdAt ?? 1_000, overrides.lastSeenAt ?? 1_000,
  );
}

test('matching creates both room seats atomically and repeated polls are idempotent', async t => {
  const db = createD1();
  t.after(() => db.close());
  const a = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
  const b = 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
  queue(db, a, { gender: 'male', preference: 'female', role: 'controller' });
  queue(db, b, { gender: 'female', preference: 'male', role: 'receiver', createdAt: 2_000 });

  const found = await findOrCreateMatch(db, a, 3_000);
  assert.equal(found.status, 'matched');
  assert.match(found.room, /^[A-HJ-NP-Z2-9]{8}$/);
  assert.equal(found.role, 'controller');

  const rows = db.raw.prepare('SELECT client_id,status,room_code,matched_role FROM matchmaking_queue ORDER BY client_id').all();
  assert.equal(rows.length, 2);
  assert.ok(rows.every(row => row.status === 'matched' && row.room_code === found.room));
  assert.deepEqual(rows.map(row => row.matched_role).sort(), ['controller', 'receiver']);

  const seats = db.raw.prepare('SELECT id,role FROM room_members WHERE room_code=? ORDER BY role').all(found.room).map(row => ({ id: row.id, role: row.role }));
  assert.deepEqual(seats, [
    { id: a, role: 'controller' },
    { id: b, role: 'receiver' },
  ]);

  const repeated = await findOrCreateMatch(db, b, 4_000);
  assert.deepEqual(repeated, { status: 'matched', room: found.room, role: 'receiver' });
  assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM room_members WHERE room_code=?').get(found.room).count, 2);
});

test('a previously matched room with missing seats is repaired from its queue records', async t => {
  const db = createD1();
  t.after(() => db.close());
  const a = 'cccccccc-cccc-4ccc-8ccc-cccccccccccc';
  const b = 'dddddddd-dddd-4ddd-8ddd-dddddddddddd';
  const room = 'AB234567';
  db.raw.prepare('INSERT INTO rooms(code,created_at,last_active_at,expires_at) VALUES(?,?,?,?)').run(room, 1_000, 1_000, 7_201_000);
  for (const [id, nickname, role] of [[a, '甲', 'controller'], [b, '乙', 'receiver']]) {
    db.raw.prepare(`INSERT INTO matchmaking_queue
      (client_id,nickname,gender,preference,role_preference,voice_preference,matched_role,status,room_code,created_at,last_seen_at)
      VALUES(?,?, 'other','any','any','any',?,'matched',?,?,?)`).run(id, nickname, role, room, 1_000, 1_000);
  }

  const repaired = await findOrCreateMatch(db, a, 5_000);
  assert.deepEqual(repaired, { status: 'matched', room, role: 'controller' });
  assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM room_members WHERE room_code=? AND left_at IS NULL').get(room).count, 2);
});

test('legacy UUID-derived room codes containing 0 or 1 remain valid for the room join protocol', async t => {
  const db = createD1();
  t.after(() => db.close());
  const a = '11111111-1111-4111-8111-111111111111';
  const b = '22222222-2222-4222-8222-222222222222';
  const oldRoom = 'EE065D14';
  db.raw.prepare('INSERT INTO rooms(code,created_at,last_active_at,expires_at) VALUES(?,?,?,?)').run(oldRoom, 1_000, 1_000, 7_201_000);
  for (const [id, nickname, role] of [[a, '甲', 'controller'], [b, '乙', 'receiver']]) {
    db.raw.prepare(`INSERT INTO matchmaking_queue
      (client_id,nickname,gender,preference,role_preference,voice_preference,matched_role,status,room_code,created_at,last_seen_at)
      VALUES(?,?, 'other','any','any','any',?,'matched',?,?,?)`).run(id, nickname, role, oldRoom, 1_000, 1_000);
  }

  const repaired = await findOrCreateMatch(db, a, 5_000);
  assert.equal(repaired.status, 'matched');
  assert.equal(repaired.room, oldRoom);
  assert.match(repaired.room, /^[A-Z0-9]{8}$/);
  assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM rooms WHERE code=?').get(oldRoom).count, 1);
  assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM room_members WHERE room_code=? AND left_at IS NULL').get(repaired.room).count, 2);
  assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM matchmaking_queue WHERE status=\'matched\' AND room_code=?').get(repaired.room).count, 2);
});

test('repair recognizes already-created seats without adding duplicate members', async t => {
  const db = createD1();
  t.after(() => db.close());
  const a = 'abababab-abab-4bab-8bab-abababababab';
  const b = 'cdcdcdcd-cdcd-4dcd-8dcd-cdcdcdcdcdcd';
  const room = 'AB234568';
  db.raw.prepare('INSERT INTO rooms(code,created_at,last_active_at,expires_at) VALUES(?,?,?,?)').run(room, 1_000, 1_000, 7_201_000);
  for (const [id, nickname, role, seat] of [
    [a, '甲', 'controller', '10101010-1010-4010-8010-101010101010'],
    [b, '乙', 'receiver', '20202020-2020-4020-8020-202020202020'],
  ]) {
    db.raw.prepare(`INSERT INTO matchmaking_queue
      (client_id,nickname,gender,preference,role_preference,voice_preference,matched_role,status,room_code,created_at,last_seen_at)
      VALUES(?,?, 'other','any','any','any',?,'matched',?,?,?)`).run(id, nickname, role, room, 1_000, 1_000);
    db.raw.prepare('INSERT INTO room_members(id,room_code,nickname,role,joined_at,last_seen_at) VALUES(?,?,?,?,?,?)')
      .run(seat, room, nickname, role, 1_000, 2_000);
  }

  const result = await findOrCreateMatch(db, a, 5_000);
  assert.deepEqual(result, { status: 'matched', room, role: 'controller' });
  assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM room_members WHERE room_code=? AND left_at IS NULL').get(room).count, 2);
});

test('incompatible candidates remain waiting and do not create a phantom room', async t => {
  const db = createD1();
  t.after(() => db.close());
  const a = 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee';
  const b = 'ffffffff-ffff-4fff-8fff-ffffffffffff';
  queue(db, a, { gender: 'male', preference: 'female', role: 'controller' });
  queue(db, b, { gender: 'female', preference: 'female', role: 'receiver' });

  assert.deepEqual(await findOrCreateMatch(db, a, 3_000), { status: 'waiting' });
  assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM rooms').get().count, 0);
  assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM room_members').get().count, 0);
});


test('poll actively pairs a waiting player with an already queued compatible player', async t => {
  const db = createD1();
  t.after(() => db.close());
  const a = '12121212-1212-4212-8212-121212121212';
  const b = '34343434-3434-4434-8434-343434343434';
  queue(db, a, { gender: 'male', preference: 'female', role: 'controller', lastSeenAt: 1_000 });
  queue(db, b, { gender: 'female', preference: 'male', role: 'receiver', createdAt: 1_500, lastSeenAt: 1_500 });

  const result = await pollMatchmaking(db, a, 3_000);
  assert.equal(result.status, 'matched');
  assert.equal(result.role, 'controller');
  assert.equal(db.raw.prepare("SELECT COUNT(*) AS count FROM room_members WHERE room_code=? AND left_at IS NULL")
    .get(result.room).count, 2);
  assert.equal(db.raw.prepare('SELECT last_seen_at FROM matchmaking_queue WHERE client_id=?').get(a).last_seen_at, 3_000);
});

test('cancel removes a waiting player and returns immediately as cancelled', async t => {
  const db = createD1();
  t.after(() => db.close());
  const a = '56565656-5656-4656-8656-565656565656';
  queue(db, a);
  assert.deepEqual(await cancelMatchmaking(db, a, 2_000), { status: 'cancelled' });
  assert.equal(db.raw.prepare('SELECT status FROM matchmaking_queue WHERE client_id=?').get(a).status, 'cancelled');
});

test('cancel never deletes an already matched room or queue result', async t => {
  const db = createD1();
  t.after(() => db.close());
  const a = '78787878-7878-4878-8878-787878787878';
  const b = '90909090-9090-4090-8090-909090909090';
  const room = 'AB234569';
  db.raw.prepare('INSERT INTO rooms(code,created_at,last_active_at,expires_at) VALUES(?,?,?,?)').run(room, 1_000, 1_000, 7_201_000);
  for (const [id, nickname, role] of [[a, '甲', 'controller'], [b, '乙', 'receiver']]) {
    db.raw.prepare(`INSERT INTO matchmaking_queue
      (client_id,nickname,gender,preference,role_preference,voice_preference,matched_role,status,room_code,created_at,last_seen_at)
      VALUES(?,?, 'other','any','any','any',?,'matched',?,?,?)`).run(id, nickname, role, room, 1_000, 1_000);
  }
  const result = await cancelMatchmaking(db, a, 5_000);
  assert.deepEqual(result, { status: 'matched', room, role: 'controller' });
  assert.equal(db.raw.prepare("SELECT COUNT(*) AS count FROM matchmaking_queue WHERE status='matched' AND room_code=?").get(room).count, 2);
  assert.equal(db.raw.prepare("SELECT COUNT(*) AS count FROM room_members WHERE room_code=? AND left_at IS NULL").get(room).count, 2);
});


test('compatibility enforces gender, role and reciprocal voice preferences', () => {
  const base = { client_id: 'a', gender: 'male', preference: 'female', role_preference: 'controller', voice_preference: 'both', created_at: 1 };
  assert.equal(isMatchCompatible(base, { ...base, client_id: 'b', gender: 'female', preference: 'male', role_preference: 'receiver', voice_preference: 'both' }), true);
  assert.equal(isMatchCompatible(base, { ...base, client_id: 'c', gender: 'female', preference: 'male', role_preference: 'receiver', voice_preference: 'off' }), false);
  assert.equal(isMatchCompatible(base, { ...base, client_id: 'd', gender: 'female', preference: 'female', role_preference: 'receiver', voice_preference: 'both' }), false);
  assert.equal(isMatchCompatible(base, { ...base, client_id: 'e', gender: 'female', preference: 'male', role_preference: 'controller', voice_preference: 'both' }), false);
});

test('partner selection prefers a mutually compatible voice match and assigns opposite roles', () => {
  const self = { client_id: 'a', gender: 'male', preference: 'female', role_preference: 'any', voice_preference: 'self', created_at: 1 };
  const peer = { client_id: 'b', gender: 'female', preference: 'male', role_preference: 'receiver', voice_preference: 'peer', created_at: 2 };
  const incompatibleVoice = { ...peer, client_id: 'c', voice_preference: 'self', created_at: 1 };
  assert.equal(chooseMatchPartner(self, [incompatibleVoice, peer]).client_id, 'b');
  assert.deepEqual(assignMatchRoles(self, peer), { selfRole: 'controller', partnerRole: 'receiver' });
});


test('simultaneous polls cannot create two rooms for the same pair', async t => {
  const db = createD1();
  t.after(() => db.close());
  const a = 'abab1212-abab-4121-8121-abab12121212';
  const b = 'cdcd3434-cdcd-4343-8343-cdcd34343434';
  queue(db, a, { gender: 'male', preference: 'female', role: 'controller' });
  queue(db, b, { gender: 'female', preference: 'male', role: 'receiver', createdAt: 2_000 });
  const results = await Promise.all([
    pollMatchmaking(db, a, 3_000),
    pollMatchmaking(db, b, 3_000),
  ]);
  assert.ok(results.every(result => result.status === 'matched'));
  assert.equal(results[0].room, results[1].room);
  const room = results[0].room;
  assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM rooms').get().count, 1);
  assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM room_members WHERE room_code=?').get(room).count, 2);
});


test('cancellation tombstone prevents an in-flight initial join from recreating the queue', async t => {
  const db = createD1();
  t.after(() => db.close());
  const a = 'abababab-1212-4121-8121-ababab121212';
  assert.deepEqual(await cancelMatchmaking(db, a, 2_000), { status: 'cancelled' });
  db.raw.prepare(`INSERT OR IGNORE INTO matchmaking_queue
    (client_id,nickname,gender,preference,role_preference,voice_preference,status,created_at,last_seen_at)
    VALUES(?, 'late join', 'male', 'any', 'any', 'any', 'waiting', 2_100, 2_100)`).run(a);
  assert.equal(db.raw.prepare('SELECT status FROM matchmaking_queue WHERE client_id=?').get(a).status, 'cancelled');
  assert.deepEqual(await pollMatchmaking(db, a, 2_500), { status: 'missing' });
  assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM rooms').get().count, 0);
});


test('matched seats whose leases expired are reactivated for reconnect', async t => {
  const db = createD1();
  t.after(() => db.close());
  const a = 'abab1212-1111-4111-8111-abab12121212';
  const b = 'cdcd3434-2222-4222-8222-cdcd34343434';
  const room = 'AB234570';
  db.raw.prepare('INSERT INTO rooms(code,created_at,last_active_at,expires_at) VALUES(?,?,?,?)').run(room, 1_000, 1_000, 7_201_000);
  for (const [id, nickname, role] of [[a, '甲', 'controller'], [b, '乙', 'receiver']]) {
    db.raw.prepare(`INSERT INTO matchmaking_queue
      (client_id,nickname,gender,preference,role_preference,voice_preference,matched_role,status,room_code,created_at,last_seen_at)
      VALUES(?,?, 'other','any','any','any',?,'matched',?,?,?)`).run(id, nickname, role, room, 1_000, 1_000);
    db.raw.prepare('INSERT INTO room_members(id,room_code,nickname,role,joined_at,last_seen_at,left_at) VALUES(?,?,?,?,?,?,?)')
      .run(id, room, nickname, role, 1_000, 1_000, 4_000);
  }
  const result = await findOrCreateMatch(db, a, 5_000);
  assert.deepEqual(result, { status: 'matched', room, role: 'controller' });
  assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM room_members WHERE room_code=? AND left_at IS NULL').get(room).count, 2);
});


test('expired matched room is not returned as a usable matchmaking result', async t => {
  const db = createD1();
  t.after(() => db.close());
  const a = 'abab1212-aaaa-4aaa-8aaa-abab12121212';
  const b = 'cdcd3434-bbbb-4bbb-8bbb-cdcd34343434';
  const room = 'AB234571';
  db.raw.prepare('INSERT INTO rooms(code,created_at,last_active_at,expires_at) VALUES(?,?,?,?)').run(room, 1_000, 1_000, 4_000);
  for (const [id, nickname, role] of [[a, '甲', 'controller'], [b, '乙', 'receiver']]) {
    db.raw.prepare(`INSERT INTO matchmaking_queue
      (client_id,nickname,gender,preference,role_preference,voice_preference,matched_role,status,room_code,created_at,last_seen_at)
      VALUES(?,?, 'other','any','any','any',?,'matched',?,?,?)`).run(id, nickname, role, room, 1_000, 1_000);
  }
  assert.deepEqual(await findOrCreateMatch(db, a, 5_000), { status: 'missing' });
});


test('the single join contract pairs compatible clients and is idempotent after matching', async t => {
  const db = createD1();
  t.after(() => db.close());
  const a = 'a1a1a1a1-1111-4111-8111-a1a1a1a1a1a1';
  const b = 'b2b2b2b2-2222-4222-8222-b2b2b2b2b2b2';
  const first = await joinMatchmaking(db, {
    clientId: a, nickname: '甲', gender: 'male', preference: 'female',
    rolePreference: 'controller', voicePreference: 'both',
  }, 10_000);
  assert.deepEqual(first, { status: 'waiting' });

  const second = await joinMatchmaking(db, {
    clientId: b, nickname: '乙', gender: 'female', preference: 'male',
    rolePreference: 'receiver', voicePreference: 'both',
  }, 11_000);
  assert.equal(second.status, 'matched');
  assert.match(second.room, /^[A-HJ-NP-Z2-9]{8}$/);
  assert.equal(second.role, 'receiver');

  const retry = await joinMatchmaking(db, {
    clientId: b, nickname: '乙', gender: 'female', preference: 'male',
    rolePreference: 'receiver', voicePreference: 'both',
  }, 12_000);
  assert.deepEqual(retry, second);
  assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM rooms').get().count, 1);
  assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM room_members WHERE room_code=?').get(second.room).count, 2);
});

test('a delayed join cannot resurrect a cancellation tombstone', async t => {
  const db = createD1();
  t.after(() => db.close());
  const id = 'c3c3c3c3-3333-4333-8333-c3c3c3c3c3c3';
  assert.deepEqual(await cancelMatchmaking(db, id, 20_000), { status: 'cancelled' });

  const late = await joinMatchmaking(db, {
    clientId: id, nickname: '迟到请求', gender: 'male', preference: 'any',
    rolePreference: 'any', voicePreference: 'any',
  }, 20_100);
  assert.deepEqual(late, { status: 'missing' });
  assert.equal(db.raw.prepare('SELECT status FROM matchmaking_queue WHERE client_id=?').get(id).status, 'cancelled');
  assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM rooms').get().count, 0);
});


test('HTTP matchmaking contract joins, polls and hands off a matched room', async t => {
  const db = createD1();
  t.after(() => db.close());
  const a = 'd4d4d4d4-4444-4444-8444-d4d4d4d4d4d4';
  const b = 'e5e5e5e5-5555-4555-8555-e5e5e5e5e5e5';
  let alarmRequests = 0;
  const request = (action, clientId, extra = {}) => new Request('https://nightplay.test/api/matchmaking', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ action, clientId, ...extra }),
  });
  const first = await handleMatchmakingApi(request('join', a, {
    nickname: '甲', gender: 'male', preference: 'female',
    rolePreference: 'controller', voicePreference: 'both',
  }), db, () => { alarmRequests += 1; });
  assert.deepEqual(await first.json(), { state: 'waiting' });

  const second = await handleMatchmakingApi(request('join', b, {
    nickname: '乙', gender: 'female', preference: 'male',
    rolePreference: 'receiver', voicePreference: 'both',
  }), db, () => { alarmRequests += 1; });
  const matched = await second.json();
  assert.equal(matched.state, 'matched');
  assert.match(matched.room, /^[A-HJ-NP-Z2-9]{8}$/);
  assert.equal(matched.role, 'receiver');
  assert.equal(alarmRequests, 1);

  const polled = await handleMatchmakingApi(request('poll', a), db);
  assert.deepEqual(await polled.json(), { state: 'matched', room: matched.room, role: 'controller' });
});

test('HTTP cancellation acknowledges immediately and later polls cannot revive the search', async t => {
  const db = createD1();
  t.after(() => db.close());
  const id = 'f6f6f6f6-6666-4666-8666-f6f6f6f6f6f6';
  const request = (action) => new Request('https://nightplay.test/api/matchmaking', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ action, clientId: id }),
  });
  const cancelled = await handleMatchmakingApi(request('cancel'), db);
  assert.deepEqual(await cancelled.json(), { state: 'cancelled' });

  const latePoll = await handleMatchmakingApi(request('poll'), db);
  assert.equal(latePoll.status, 404);
  assert.deepEqual(await latePoll.json(), { state: 'missing', message: '匹配请求已失效，请重新开始。' });
});

test('HTTP matchmaking rejects cross-origin requests before touching the queue', async t => {
  const db = createD1();
  t.after(() => db.close());
  const response = await handleMatchmakingApi(new Request('https://nightplay.test/api/matchmaking', {
    method: 'POST',
    headers: { origin: 'https://attacker.test', 'content-type': 'application/json' },
    body: JSON.stringify({ action: 'cancel', clientId: 'a7a7a7a7-7777-4777-8777-a7a7a7a7a7a7' }),
  }), db);
  assert.equal(response.status, 403);
  assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM matchmaking_queue').get().count, 0);
});


test('a cancel racing a poll either wins cleanly or returns the committed match', async t => {
  const db = createD1();
  t.after(() => db.close());
  const a = 'a8a8a8a8-8888-4888-8888-a8a8a8a8a8a8';
  const b = 'b9b9b9b9-9999-4999-8999-b9b9b9b9b9b9';
  queue(db, a, { gender: 'male', preference: 'female', role: 'controller' });
  queue(db, b, { gender: 'female', preference: 'male', role: 'receiver', createdAt: 2_000 });

  const [polled, cancelled] = await Promise.all([
    pollMatchmaking(db, a, 3_000),
    cancelMatchmaking(db, a, 3_000),
  ]);
  const self = db.raw.prepare('SELECT status,room_code,matched_role FROM matchmaking_queue WHERE client_id=?').get(a);
  const partner = db.raw.prepare('SELECT status,room_code,matched_role FROM matchmaking_queue WHERE client_id=?').get(b);

  if (self.status === 'matched') {
    assert.equal(partner.status, 'matched');
    assert.equal(self.room_code, partner.room_code);
    assert.notEqual(self.matched_role, partner.matched_role);
    assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM room_members WHERE room_code=? AND left_at IS NULL').get(self.room_code).count, 2);
    assert.ok(['matched'].includes(polled.status));
    assert.ok(['matched'].includes(cancelled.status));
  } else {
    assert.equal(self.status, 'cancelled');
    assert.equal(partner.status, 'waiting');
    assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM rooms').get().count, 0);
    assert.equal(db.raw.prepare('SELECT COUNT(*) AS count FROM room_members').get().count, 0);
  }
});
