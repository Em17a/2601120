# Nightplay 双向语音与隐私说明（Cloudflare 迁移版）

## 语音工作方式

- 双方分别主动点击“开启麦克风”并授权后，浏览器通过 WebRTC 建立双向语音。
- 音频媒体仍由浏览器点对点传输；Cloudflare Worker / Durable Object 只转发 WebRTC offer、answer 和 ICE candidate，不写入聊天历史。
- 网站必须通过 HTTPS 访问才能使用麦克风。
- 默认使用 Google STUN。部分移动网络、运营商 NAT 或企业网络可能需要 TURN；不配置 TURN 时不能保证所有网络都能连通。
- 可在 Worker 环境变量中配置 `NIGHTPLAY_TURN_URLS`、`NIGHTPLAY_TURN_SHARED_SECRET` 和 `NIGHTPLAY_TURN_TTL_SECONDS`。共享密钥只能保存在服务端环境变量中。

## 联系方式防泄漏

- 文字消息在浏览器和 Durable Object 服务端双重检测；服务端检测为最终拦截点，命中的原文不会写入 D1 或广播。
- 检测覆盖手机号、邮箱、常见社交平台账号/链接、中文数字及常见空格/标点拆分，并对同一连接 12 秒内相邻消息做短时拼接检测。
- 短时拼接文本、违规计数及限制状态仅保存在当前 WebSocket 连接的 Durable Object attachment 中，不写入 D1。连接断开或重新进入后不保证延续。
- 语音检测使用浏览器 SpeechRecognition 的 `processLocally` 设备端模式（中文 `zh-CN`）。只有浏览器明确支持该能力时才允许开启麦克风；不回退到云端识别。若支持语言包安装，会由浏览器安装设备端语言模型。
- 识别到疑似联系方式后，客户端立即禁用本地音轨并停止识别，再向服务端发送违规事件。识别文本只存在于当前事件处理内存中，不展示、不写入日志、不保存为聊天记录。
- 为降低识别延迟造成的语音先行泄漏，WebRTC 上行音频增加约 1.6 秒本地缓冲；缓冲会增加通话延迟，但识别速度仍可能慢于缓冲时间。

## 重要限制

浏览器端语音识别属于尽力而为的客户端保护，识别有延迟、误识别和漏识别可能；WebRTC 音频在识别结果返回前可能已经传出，且有技术能力的用户可修改客户端绕过。该方案不能保证零泄漏，也不能替代服务端媒体中继/审核。若浏览器不支持 `processLocally`，原页面会阻止麦克风开启。

上线前仍需完成适用法律要求的隐私告知、同意与数据处理评估。语音不录音，完整语音转写不保存。

## 部署

Cloudflare 迁移、D1 初始化和部署步骤请查看 [`README_CLOUDFLARE.md`](./README_CLOUDFLARE.md)。
